import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';
import 'package:permission_handler/permission_handler.dart';

class Blu extends StatefulWidget {
  const Blu({super.key});

  @override
  State<Blu> createState() => _BluState();
}

class _BluState extends State<Blu> {
  static final Guid serviceUuid = Guid("12345678-1234-1234-1234-1234567890ab");
  static final Guid txUuid = Guid("12345678-1234-1234-1234-1234567890ac");
  static final Guid rxUuid = Guid("12345678-1234-1234-1234-1234567890ad");

  StreamSubscription<List<ScanResult>>? _scanSub;
  StreamSubscription<List<int>>? _notifySub;
  StreamSubscription<bool>? _isScanningSub;

  final Map<String, ScanResult> _resultsById = {};

  BluetoothDevice? _device;
  BluetoothCharacteristic? _txChar;
  BluetoothCharacteristic? _rxChar;

  bool _scanning = false;
  String _status = "Please connect a device";
  String _lastMsg = "";

  @override
  void dispose() {
    _notifySub?.cancel();
    _scanSub?.cancel();
    _isScanningSub?.cancel();
    super.dispose();
  }

  Future<bool> ensureBlePermissions() async {
    final scan = await Permission.bluetoothScan.request();
    final connect = await Permission.bluetoothConnect.request();
    await Permission.locationWhenInUse.request();
    return scan.isGranted && connect.isGranted;
  }

  Future<void> _startScan() async {
    if (!await FlutterBluePlus.isSupported) {
      setState(() => _status = "BLE not supported on this device");
      return;
    }

    final state = await FlutterBluePlus.adapterState.first;
    if (state != BluetoothAdapterState.on) {
      setState(() => _status = "Please turn Bluetooth ON");
      return;
    }

    setState(() {
      _resultsById.clear();
      _scanning = true;
      _status = "Scanning...";
    });

    _scanSub?.cancel();
    _isScanningSub?.cancel();

    _scanSub = FlutterBluePlus.scanResults.listen((results) {
      for (final r in results) {
        _resultsById[r.device.remoteId.str] = r;
      }
      if (mounted) {
        setState(() {});
      }
    });

    _isScanningSub = FlutterBluePlus.isScanning.listen((isScanning) {
      if (!mounted) return;

      if (!isScanning) {
        setState(() {
          _scanning = false;
          _status = _resultsById.isEmpty
              ? "No devices found"
              : "Tap a device to connect";
        });
      }
    });

    await FlutterBluePlus.startScan(timeout: const Duration(seconds: 6));
  }

  Future<void> _connect(ScanResult r) async {
    final d = r.device;

    setState(() {
      _status =
          "Connecting to ${d.advName.isNotEmpty ? d.advName : d.remoteId.str} ...";
      _device = d;
    });

    try {
      await FlutterBluePlus.stopScan();
    } catch (_) {}

    try {
      await d.connect(timeout: const Duration(seconds: 10));
    } catch (_) {}

    try {
      final services = await d.discoverServices();
      final svc = services.firstWhere((s) => s.uuid == serviceUuid);

      _txChar = svc.characteristics.firstWhere((c) => c.uuid == txUuid);
      _rxChar = svc.characteristics.firstWhere((c) => c.uuid == rxUuid);

      await _txChar!.setNotifyValue(true);

      _notifySub?.cancel();
      _notifySub = _txChar!.onValueReceived.listen((value) {
        final msg = String.fromCharCodes(value);
        if (mounted) {
          setState(() => _lastMsg = msg);
        }
      });

      setState(() => _status = "Connection successful");
    } catch (_) {
      setState(() {
        _status = "Connection failed";
        _device = null;
        _txChar = null;
        _rxChar = null;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final results = _resultsById.values.toList()
      ..sort((a, b) => b.rssi.compareTo(a.rssi));

    return Center(
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 24, vertical: 24),
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(28),
          border: Border.all(color: Colors.black, width: 1.5),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              _status,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 16, color: Colors.white),
            ),
            const SizedBox(height: 12),

            ElevatedButton.icon(
              onPressed: _scanning
                  ? null
                  : () async {
                      final ok = await ensureBlePermissions();
                      if (!ok) {
                        setState(() => _status = "Bluetooth permission denied");
                        return;
                      }
                      await _startScan();
                    },
              icon: const Icon(Icons.bluetooth),
              label: Text(_scanning ? "Scanning..." : "Connect"),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color.fromARGB(255, 41, 53, 126),
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(
                  horizontal: 32,
                  vertical: 14,
                ),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(24),
                ),
              ),
            ),

            const SizedBox(height: 16),

            SizedBox(
              height: 220,
              child: results.isEmpty
                  ? const Center(
                      child: Text(
                        "No devices yet",
                        style: TextStyle(color: Colors.white70),
                      ),
                    )
                  : ListView.builder(
                      itemCount: results.length,
                      itemBuilder: (context, i) {
                        final r = results[i];
                        final name = r.device.advName.isNotEmpty
                            ? r.device.advName
                            : "(no name)";

                        return ListTile(
                          title: Text(
                            name,
                            style: const TextStyle(color: Colors.white),
                          ),
                          subtitle: Text(
                            "${r.device.remoteId.str} RSSI ${r.rssi}",
                            style: const TextStyle(color: Colors.white70),
                          ),
                          onTap: () => _connect(r),
                        );
                      },
                    ),
            ),

            if (_lastMsg.isNotEmpty) ...[
              const SizedBox(height: 8),
              Text(
                "Last message: $_lastMsg",
                style: const TextStyle(color: Colors.white70, fontSize: 11),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
            ],
          ],
        ),
      ),
    );
  }
}
