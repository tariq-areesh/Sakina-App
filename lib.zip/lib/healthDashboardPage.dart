import 'dart:async';
import 'dart:math';
import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';

class HealthDashboardPage extends StatefulWidget {
  const HealthDashboardPage({super.key});

  @override
  State<HealthDashboardPage> createState() => _HealthDashboardPageState();
}

class _HealthDashboardPageState extends State<HealthDashboardPage> {
  static const int maxPoints = 24;
  static const double stepX = 0.5;

  final Random _random = Random();

  Timer? _timer;

  List<FlSpot> _bvpSpots = [];
  List<FlSpot> _tempSpots = [];

  double _currentX = 0.0;
  double _tempBase = 35.0;

  @override
  void initState() {
    super.initState();
    _seedData();
    _startSimulation();
  }

  void _seedData() {
    _bvpSpots = [];
    _tempSpots = [];

    double x = 0.0;
    for (int i = 0; i < maxPoints; i++) {
      _bvpSpots.add(FlSpot(x, _generateBvpValue(x)));
      _tempSpots.add(FlSpot(x, _generateTempValue(x)));
      x += stepX;
    }

    _currentX = _bvpSpots.isNotEmpty ? _bvpSpots.last.x : 0.0;
  }

  void _startSimulation() {
    _timer?.cancel();

    _timer = Timer.periodic(const Duration(milliseconds: 700), (_) {
      if (!mounted) return;

      setState(() {
        _currentX += stepX;

        final newBvp = FlSpot(_currentX, _generateBvpValue(_currentX));
        final newTemp = FlSpot(_currentX, _generateTempValue(_currentX));

        _bvpSpots = [..._bvpSpots, newBvp];
        _tempSpots = [..._tempSpots, newTemp];

        if (_bvpSpots.length > maxPoints) {
          _bvpSpots.removeAt(0);
        }
        if (_tempSpots.length > maxPoints) {
          _tempSpots.removeAt(0);
        }
      });
    });
  }

  double _generateBvpValue(double x) {
    final cycle = x % 3.2;

    double pulse;
    if (cycle < 0.45) {
      pulse = cycle / 0.45;
    } else if (cycle < 1.1) {
      pulse = 1.0 - ((cycle - 0.45) / 0.65) * 0.55;
    } else {
      pulse = 0.45 - ((cycle - 1.1) / 2.1) * 0.08;
    }

    final notch = sin(x * 1.7) * 0.015;
    final noise = (_random.nextDouble() - 0.5) * 0.02;

    final value = 0.42 + (pulse * 0.22) + notch + noise;
    return value.clamp(0.30, 0.78);
  }

  double _generateTempValue(double x) {
    _tempBase += (_random.nextDouble() - 0.5) * 0.01;
    _tempBase = _tempBase.clamp(34.9, 35.3);

    final slowWave = sin(x * 0.8) * 0.12;
    final mediumWave = sin(x * 1.9) * 0.05;
    final noise = (_random.nextDouble() - 0.5) * 0.015;

    final value = _tempBase + slowWave + mediumWave + noise;
    return value.clamp(34.6, 35.5);
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(8, 10, 8, 10),
      child: Column(
        children: [
          const SizedBox(height: 4),
          const Text(
            "Dashboard",
            style: TextStyle(
              color: Colors.white,
              fontSize: 21,
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(height: 10),

          Expanded(
            child: _DashboardCard(
              title: "Blood Volume Pulse (BVP)",
              child: _RealtimeLineChart(
                spots: _normalizedSpots(_bvpSpots),
                minY: 0.2,
                maxY: 0.9,
                leftTitle: "Raw",
                bottomTitle: "Time (s)",
                xLabelBuilder: (value) => value.toInt().toString(),
                yLabelBuilder: (value) => value.toStringAsFixed(1),
                lineColor: const Color(0xFF2F6BFF),
              ),
            ),
          ),

          const SizedBox(height: 10),

          Expanded(
            child: _DashboardCard(
              title: "Body Temperature",
              child: _RealtimeLineChart(
                spots: _normalizedSpots(_tempSpots),
                minY: 34.0,
                maxY: 37.0,
                leftTitle: "C°",
                bottomTitle: "Time (s)",
                xLabelBuilder: (value) => value.toInt().toString(),
                yLabelBuilder: (value) {
                  if (value % 1 == 0) return value.toInt().toString();
                  return value.toStringAsFixed(1);
                },
                lineColor: const Color(0xFF2AA1FF),
              ),
            ),
          ),
        ],
      ),
    );
  }

  List<FlSpot> _normalizedSpots(List<FlSpot> source) {
    if (source.isEmpty) return [];

    final firstX = source.first.x;
    return source
        .map((spot) => FlSpot(spot.x - firstX, spot.y))
        .toList();
  }
}

class _DashboardCard extends StatelessWidget {
  final String title;
  final Widget child;

  const _DashboardCard({
    required this.title,
    required this.child,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(12, 10, 12, 12),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.black, width: 1.5),
      ),
      child: Column(
        children: [
          Text(
            title,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 17,
              fontWeight: FontWeight.w400,
            ),
          ),
          const SizedBox(height: 8),
          Expanded(child: child),
        ],
      ),
    );
  }
}

class _RealtimeLineChart extends StatelessWidget {
  final List<FlSpot> spots;
  final double minY;
  final double maxY;
  final String leftTitle;
  final String bottomTitle;
  final String Function(double value) xLabelBuilder;
  final String Function(double value) yLabelBuilder;
  final Color lineColor;

  const _RealtimeLineChart({
    required this.spots,
    required this.minY,
    required this.maxY,
    required this.leftTitle,
    required this.bottomTitle,
    required this.xLabelBuilder,
    required this.yLabelBuilder,
    required this.lineColor,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Expanded(
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              SizedBox(
                width: 24,
                child: Center(
                  child: RotatedBox(
                    quarterTurns: 3,
                    child: Text(
                      leftTitle,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 12,
                      ),
                    ),
                  ),
                ),
              ),
              Expanded(
                child: LineChart(
                  LineChartData(
                    minX: 0,
                    maxX: 11.5,
                    minY: minY,
                    maxY: maxY,
                    backgroundColor: Colors.transparent,
                    clipData: const FlClipData.all(),
                    gridData: FlGridData(
                      show: true,
                      drawVerticalLine: true,
                      horizontalInterval: (maxY - minY) / 5,
                      verticalInterval: 1,
                      getDrawingHorizontalLine: (_) {
                        return FlLine(
                          color: Colors.white.withOpacity(0.18),
                          strokeWidth: 1,
                        );
                      },
                      getDrawingVerticalLine: (_) {
                        return FlLine(
                          color: Colors.white.withOpacity(0.18),
                          strokeWidth: 1,
                        );
                      },
                    ),
                    borderData: FlBorderData(
                      show: true,
                      border: Border.all(
                        color: Colors.white.withOpacity(0.30),
                        width: 1,
                      ),
                    ),
                    titlesData: FlTitlesData(
                      topTitles: const AxisTitles(
                        sideTitles: SideTitles(showTitles: false),
                      ),
                      rightTitles: const AxisTitles(
                        sideTitles: SideTitles(showTitles: false),
                      ),
                      leftTitles: AxisTitles(
                        sideTitles: SideTitles(
                          showTitles: true,
                          reservedSize: 28,
                          interval: (maxY - minY) / 5,
                          getTitlesWidget: (value, meta) {
                            return Text(
                              yLabelBuilder(value),
                              style: TextStyle(
                                color: Colors.white.withOpacity(0.75),
                                fontSize: 9,
                              ),
                            );
                          },
                        ),
                      ),
                      bottomTitles: AxisTitles(
                        sideTitles: SideTitles(
                          showTitles: true,
                          reservedSize: 22,
                          interval: 1,
                          getTitlesWidget: (value, meta) {
                            return Padding(
                              padding: const EdgeInsets.only(top: 4),
                              child: Text(
                                xLabelBuilder(value),
                                style: TextStyle(
                                  color: Colors.white.withOpacity(0.75),
                                  fontSize: 9,
                                ),
                              ),
                            );
                          },
                        ),
                      ),
                    ),
                    lineBarsData: [
                      LineChartBarData(
                        spots: spots,
                        isCurved: true,
                        curveSmoothness: 0.22,
                        color: lineColor,
                        barWidth: 2.2,
                        isStrokeCapRound: true,
                        dotData: const FlDotData(show: false),
                        belowBarData: BarAreaData(
                          show: true,
                          color: lineColor.withOpacity(0.08),
                        ),
                      ),
                    ],
                    lineTouchData: const LineTouchData(enabled: false),
                  ),
                  duration: const Duration(milliseconds: 1000),
                  curve: Curves.easeInOut,
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 8),
        Text(
          bottomTitle,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 12,
          ),
        ),
      ],
    );
  }
}