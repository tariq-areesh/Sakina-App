import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';

class HomePage extends StatefulWidget {
  final BluetoothDevice? device;
  final BluetoothCharacteristic? txChar;
  final BluetoothCharacteristic? rxChar;
  final String initialMessage;

  const HomePage({
    super.key,
    this.device,
    this.txChar,
    this.rxChar,
    this.initialMessage = "",
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class HomePagePreview extends StatelessWidget {
  const HomePagePreview({super.key});

  @override
  Widget build(BuildContext context) {
    return const HomePage();
  }
}

class _HomePageState extends State<HomePage> {
  late String _lastMessage;

  String stressStatus = "Normal";
  String medicalAdvice = "You are in a balanced state.\nKeep maintaining your current routine.";
  String skinTemp = "34.2°C";
  String heartRate = "78 bpm";

  StreamSubscription<List<int>>? _notifySub;
  Timer? _simulationTimer;
  final Random _random = Random();

  double _currentTemp = 34.2;
  int _currentHr = 78;

  @override
  void initState() {
    super.initState();
    _lastMessage = widget.initialMessage;
    _listenToBleNotifications();

    if (_lastMessage.isNotEmpty) {
      _parseEsp32Message(_lastMessage);
    } else {
      _startSimulation();
    }
  }

  void _listenToBleNotifications() {
    if (widget.txChar == null) {
      return;
    }

    _notifySub = widget.txChar!.onValueReceived.listen((value) {
      final msg = String.fromCharCodes(value);

      if (!mounted) return;

      // Stop simulation when real BLE data arrives
      _simulationTimer?.cancel();

      setState(() {
        _lastMessage = msg;
      });

      _parseEsp32Message(msg);
    });
  }

  void _startSimulation() {
    _simulationTimer?.cancel();

    _simulationTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) return;

      setState(() {
        // Heart rate: believable resting range with small fluctuations
        _currentHr += _random.nextInt(5) - 2; // -2 to +2
        _currentHr = _currentHr.clamp(72, 92);

        // Temperature: believable skin temp range with tiny fluctuations
        _currentTemp += (_random.nextDouble() * 0.2) - 0.1; // -0.1 to +0.1
        _currentTemp = _currentTemp.clamp(33.8, 35.4);

        heartRate = "$_currentHr bpm";
        skinTemp = "${_currentTemp.toStringAsFixed(1)}°C";

        if (_currentHr <= 85) {
          stressStatus = "Normal";
          medicalAdvice =
              "You are in a balanced state.\nKeep maintaining your current routine.";
        } else if (_currentHr <= 95) {
          stressStatus = "Mild Stress";
          medicalAdvice =
              "Slightly elevated HR detected.\nTry a 1-minute deep breathing exercise.";
        } else if (_currentHr <= 110) {
          stressStatus = "Moderate Stress";
          medicalAdvice =
              "Moderate stress detected.\nTake a 5-minute walk or step away.";
        } else {
          stressStatus = "High Stress";
          medicalAdvice =
              "High stress alert.\nSit down and focus on slow exhales.";
        }
      });
    });
  }

  void _parseEsp32Message(String msg) {
    try {
      final parts = msg.split(',');
      final Map<String, String> data = {};

      for (final part in parts) {
        final kv = part.split(':');
        if (kv.length >= 2) {
          final key = kv.first.trim().toLowerCase();
          final value = kv.sublist(1).join(':').trim();
          data[key] = value;
        }
      }

      setState(() {
        if (data.containsKey('stress')) {
          stressStatus = data['stress']!;
        }
        if (data.containsKey('temp')) {
          skinTemp = "${data['temp']}°C";
        }
        if (data.containsKey('hr')) {
          heartRate = "${data['hr']} bpm";
        }
        if (data.containsKey('advice')) {
          medicalAdvice = data['advice']!;
        }
      });
    } catch (_) {
      // ignore invalid messages
    }
  }

  @override
  void dispose() {
    _notifySub?.cancel();
    _simulationTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final deviceName =
        widget.device != null && widget.device!.advName.isNotEmpty
            ? widget.device!.advName
            : "No device connected";

    return _HomePageContent(
      deviceName: deviceName,
      stressStatus: stressStatus,
      medicalAdvice: medicalAdvice,
      skinTemp: skinTemp,
      heartRate: heartRate,
      lastMessage: _lastMessage,
    );
  }
}

class _HomePageContent extends StatelessWidget {
  final String deviceName;
  final String stressStatus;
  final String medicalAdvice;
  final String skinTemp;
  final String heartRate;
  final String lastMessage;

  const _HomePageContent({
    required this.deviceName,
    required this.stressStatus,
    required this.medicalAdvice,
    required this.skinTemp,
    required this.heartRate,
    required this.lastMessage,
  });

  @override
  Widget build(BuildContext context) {
    const lightCard = Color(0xFFC4D8BE);

    return Padding(
      padding: const EdgeInsets.fromLTRB(8, 10, 8, 10),
      child: Column(
        children: [
          _roundedCard(
            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
            child: Text(
              "Device Name: $deviceName",
              style: const TextStyle(color: Colors.white, fontSize: 18),
            ),
          ),
          const SizedBox(height: 10),
          Expanded(
            flex: 4,
            child: _roundedCard(
              child: Column(
                children: [
                  const Padding(
                    padding: EdgeInsets.symmetric(vertical: 10),
                    child: Text(
                      "Stress Status",
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 20,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                  const Divider(height: 1, thickness: 1, color: Colors.black45),
                  Expanded(
                    child: Stack(
                      children: [
                        Center(
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 34,
                              vertical: 16,
                            ),
                            decoration: BoxDecoration(
                              color: lightCard,
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Text(
                              stressStatus,
                              style: const TextStyle(
                                color: Colors.black87,
                                fontSize: 18,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ),
                        ),
                        const Positioned(
                          right: 14,
                          bottom: 12,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Text(
                                "Check",
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 12,
                                ),
                              ),
                              Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Text(
                                    "Stress History",
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 12,
                                    ),
                                  ),
                                  SizedBox(width: 3),
                                  Icon(
                                    Icons.arrow_forward_ios,
                                    size: 13,
                                    color: Colors.white,
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 10),
          Expanded(
            flex: 3,
            child: _roundedCard(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Row(
                    children: [
                      Icon(
                        Icons.medical_information_outlined,
                        color: Colors.white,
                        size: 20,
                      ),
                      SizedBox(width: 8),
                      Text(
                        "Advice",
                        style: TextStyle(color: Colors.white, fontSize: 16),
                      ),
                    ],
                  ),
                  const Spacer(),
                  Center(
                    child: Text(
                      medicalAdvice,
                      textAlign: TextAlign.center,
                      style: const TextStyle(color: Colors.white, fontSize: 17),
                    ),
                  ),
                  const Spacer(),
                ],
              ),
            ),
          ),
          const SizedBox(height: 10),
          Expanded(
            flex: 3,
            child: Row(
              children: [
                Expanded(
                  child: _metricCard(
                    title: "Current\nSkin Temperature",
                    value: skinTemp,
                    icon: Icons.device_thermostat_outlined,
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: _metricCard(
                    title: "Current\nHeart Rate",
                    value: heartRate,
                    icon: Icons.favorite_outline,
                  ),
                ),
              ],
            ),
          ),
          if (lastMessage.isNotEmpty) ...[
            const SizedBox(height: 8),
            Text(
              "BLE: $lastMessage",
              style: const TextStyle(color: Colors.white70, fontSize: 11),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ],
      ),
    );
  }
}

class _roundedCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry? padding;

  const _roundedCard({
    required this.child,
    this.padding,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: padding,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: Colors.black, width: 1.5),
      ),
      child: child,
    );
  }
}

class _metricCard extends StatelessWidget {
  final String title;
  final String value;
  final IconData icon;

  const _metricCard({
    required this.title,
    required this.value,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        border: Border.all(color: Colors.black, width: 1.5),
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(icon, color: Colors.black54, size: 24),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    title,
                    style: const TextStyle(color: Colors.white, fontSize: 13),
                  ),
                ),
              ],
            ),
            const Spacer(),
            Center(
              child: Text(
                value,
                style: const TextStyle(color: Colors.white, fontSize: 22),
              ),
            ),
            const Spacer(),
          ],
        ),
      ),
    );
  }
}