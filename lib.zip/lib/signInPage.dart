import 'package:flutter/material.dart';

class SignInPage extends StatelessWidget {
  const SignInPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                Color.fromARGB(255, 41, 53, 126),
                Color.fromARGB(255, 70, 150, 144),
              ],
              begin: Alignment.centerLeft,
              end: Alignment.centerRight,
            ),
          ),
          child: Stack(
            children: [
              Positioned(
                left: 135,
                top: 62,
                child: Image.asset('assets/logo.png', height: 150, width: 150),
              ),
            ],
          ),
        ),
        toolbarHeight: 150,
      ),
      body: Center(
        child: Stack(
          children: [
            Center(
              child: ElevatedButton(
                onPressed: SignInPage.new,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Color.fromARGB(255, 41, 53, 126),
                ),
                child: Text(
                  "التسجيل",
                  style: TextStyle(color: Color.fromARGB(255, 255, 255, 255)),
                ),
              ),
            ),
          ],
        ),
      ),

      bottomSheet: Container(
        height: 200,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              Color.fromARGB(255, 41, 53, 126),
              Color.fromARGB(255, 70, 150, 144),
            ],
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
          ),
        ),
      ),
    );
  }
}
