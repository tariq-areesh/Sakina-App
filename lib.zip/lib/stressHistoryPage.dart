import 'package:flutter/material.dart';

class StressHistoryPage extends StatefulWidget {
  const StressHistoryPage({super.key});

  @override
  State<StressHistoryPage> createState() => _StressHistoryPageState();
}

class _StressHistoryPageState extends State<StressHistoryPage> {
  final TextEditingController _searchController = TextEditingController();

  final List<StressHistoryItem> _allItems = List.generate(24, (index) {
    final second = 20 + index;
    final status = (index % 5 == 0 || index % 5 == 1) ? "Normal" : "Stressed";

    return StressHistoryItem(
      status: status,
      timestamp: "2025-12-06 13:33:${second.toString().padLeft(2, '0')}",
    );
  });

  String _selectedTimeUnit = "Second";
  String _selectedStatus = "Both";
  String _searchText = "";

  List<StressHistoryItem> get _filteredItems {
    return _allItems.where((item) {
      final matchesSearch =
          _searchText.isEmpty ||
          item.timestamp.toLowerCase().contains(_searchText.toLowerCase()) ||
          item.status.toLowerCase().contains(_searchText.toLowerCase());

      final matchesStatus =
          _selectedStatus == "Both" || item.status == _selectedStatus;

      return matchesSearch && matchesStatus;
    }).toList();
  }

  void _openFilterDialog() {
    String tempTimeUnit = _selectedTimeUnit;
    String tempStatus = _selectedStatus;

    showDialog(
      context: context,
      barrierColor: Colors.black38,
      builder: (context) {
        return Dialog(
          backgroundColor: Colors.transparent,
          insetPadding: const EdgeInsets.symmetric(horizontal: 26),
          child: Container(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 14),
            decoration: BoxDecoration(
              color: const Color(0xFF9CAF84),
              borderRadius: BorderRadius.circular(12),
              boxShadow: const [
                BoxShadow(
                  color: Colors.black26,
                  blurRadius: 8,
                  offset: Offset(0, 2),
                ),
              ],
            ),
            child: StatefulBuilder(
              builder: (context, setLocalState) {
                Widget filterOption({
                  required String label,
                  required bool selected,
                  required VoidCallback onTap,
                }) {
                  return GestureDetector(
                    onTap: onTap,
                    child: Container(
                      height: 32,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        color: selected
                            ? const Color(0xFF666666)
                            : const Color(0xFFE8E8E8),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Text(
                        label,
                        style: TextStyle(
                          color: selected ? Colors.white : Colors.black87,
                          fontSize: 14,
                        ),
                      ),
                    ),
                  );
                }

                return Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(
                          child: Column(
                            children: [
                              const Align(
                                alignment: Alignment.centerLeft,
                                child: Text(
                                  "View Data By:",
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 15,
                                  ),
                                ),
                              ),
                              const SizedBox(height: 18),
                              filterOption(
                                label: "MiliSeconds",
                                selected: tempTimeUnit == "MiliSeconds",
                                onTap: () => setLocalState(() {
                                  tempTimeUnit = "MiliSeconds";
                                }),
                              ),
                              const SizedBox(height: 18),
                              filterOption(
                                label: "Second",
                                selected: tempTimeUnit == "Second",
                                onTap: () => setLocalState(() {
                                  tempTimeUnit = "Second";
                                }),
                              ),
                              const SizedBox(height: 18),
                              filterOption(
                                label: "Hours",
                                selected: tempTimeUnit == "Hours",
                                onTap: () => setLocalState(() {
                                  tempTimeUnit = "Hours";
                                }),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 28),
                        Expanded(
                          child: Column(
                            children: [
                              const Align(
                                alignment: Alignment.centerLeft,
                                child: Text(
                                  "Viewed Status",
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 15,
                                  ),
                                ),
                              ),
                              const SizedBox(height: 18),
                              filterOption(
                                label: "Normal",
                                selected: tempStatus == "Normal",
                                onTap: () => setLocalState(() {
                                  tempStatus = "Normal";
                                }),
                              ),
                              const SizedBox(height: 18),
                              filterOption(
                                label: "Stressed",
                                selected: tempStatus == "Stressed",
                                onTap: () => setLocalState(() {
                                  tempStatus = "Stressed";
                                }),
                              ),
                              const SizedBox(height: 18),
                              filterOption(
                                label: "Both",
                                selected: tempStatus == "Both",
                                onTap: () => setLocalState(() {
                                  tempStatus = "Both";
                                }),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 28),
                    SizedBox(
                      width: 94,
                      height: 32,
                      child: ElevatedButton(
                        onPressed: () {
                          setState(() {
                            _selectedTimeUnit = tempTimeUnit;
                            _selectedStatus = tempStatus;
                          });
                          Navigator.pop(context);
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.white,
                          foregroundColor: Colors.black87,
                          elevation: 0,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                        ),
                        child: const Text("Apply"),
                      ),
                    ),
                  ],
                );
              },
            ),
          ),
        );
      },
    );
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(8, 10, 8, 10),
      child: Column(
        children: [
          const SizedBox(height: 6),
          const Text(
            "Stress History",
            style: TextStyle(
              color: Colors.white,
              fontSize: 20,
              fontWeight: FontWeight.w500,
              fontFamily: "Times New Roman",
            ),
          ),
          const SizedBox(height: 10),

          Center(
            child: SizedBox(
              width: 118,
              height: 32,
              child: ElevatedButton.icon(
                onPressed: _openFilterDialog,
                icon: const Icon(
                  Icons.filter_alt_outlined,
                  color: Colors.black54,
                  size: 22,
                ),
                label: const Text(
                  "Filter",
                  style: TextStyle(
                    color: Colors.black87,
                    fontSize: 15,
                  ),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFD9D9D9),
                  elevation: 0,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
              ),
            ),
          ),

          const SizedBox(height: 8),

          TextField(
            controller: _searchController,
            onChanged: (value) {
              setState(() {
                _searchText = value.trim();
              });
            },
            decoration: InputDecoration(
              hintText: "Search Time",
              hintStyle: const TextStyle(
                color: Colors.black54,
                fontSize: 14,
              ),
              filled: true,
              fillColor: Colors.white,
              contentPadding: const EdgeInsets.symmetric(
                horizontal: 14,
                vertical: 12,
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: const BorderSide(
                  color: Colors.black54,
                  width: 1.2,
                ),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: const BorderSide(
                  color: Colors.black87,
                  width: 1.3,
                ),
              ),
            ),
          ),

          const SizedBox(height: 10),

          Container(
            color: const Color(0xFF6C6C6C),
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            child: const Row(
              children: [
                Expanded(
                  child: Center(
                    child: Text(
                      "Status",
                      style: TextStyle(color: Colors.white, fontSize: 16),
                    ),
                  ),
                ),
                Expanded(
                  flex: 2,
                  child: Center(
                    child: Text(
                      "Time Stamp",
                      style: TextStyle(color: Colors.white, fontSize: 16),
                    ),
                  ),
                ),
              ],
            ),
          ),

          Expanded(
            child: _filteredItems.isEmpty
                ? const Center(
                    child: Text(
                      "No matching history",
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                      ),
                    ),
                  )
                : ListView.separated(
                    padding: const EdgeInsets.only(top: 6),
                    itemCount: _filteredItems.length,
                    separatorBuilder: (_, __) => Container(
                      height: 1,
                      color: Colors.black38,
                    ),
                    itemBuilder: (context, index) {
                      final item = _filteredItems[index];
                      return Padding(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 6,
                          vertical: 8,
                        ),
                        child: Row(
                          children: [
                            Expanded(
                              child: Center(
                                child: Text(
                                  item.status,
                                  style: const TextStyle(
                                    color: Colors.black87,
                                    fontSize: 15,
                                  ),
                                ),
                              ),
                            ),
                            Expanded(
                              flex: 2,
                              child: Center(
                                child: Text(
                                  item.timestamp,
                                  style: const TextStyle(
                                    color: Colors.black87,
                                    fontSize: 15,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}

class StressHistoryItem {
  final String status;
  final String timestamp;

  StressHistoryItem({
    required this.status,
    required this.timestamp,
  });
}